const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.ALLOWED_ORIGIN || '*' },
  maxHttpBufferSize: 1e6,
  pingInterval: 25000,
  pingTimeout: 20000
});
const PORT = Number(process.env.PORT || 3000);
const rooms = new Map();
const MAX_PER_ROOM = Number(process.env.MAX_PER_ROOM || 8);

app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));
app.get('/health', (_req, res) => res.json({ ok: true }));

function cleanName(value) {
  const s = String(value || 'کاربر').replace(/[<>]/g, '').trim().slice(0, 32);
  return s || 'کاربر';
}
function cleanRoom(value) {
  return String(value || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 32);
}
function getRoom(room) {
  if (!rooms.has(room)) rooms.set(room, new Map());
  return rooms.get(room);
}
io.on('connection', socket => {
  socket.data.room = null;
  socket.on('join-room', ({ room: rawRoom, name: rawName } = {}) => {
    const room = cleanRoom(rawRoom);
    const name = cleanName(rawName);
    if (!room) return;
    if (socket.data.room) leaveRoom(socket);
    const members = getRoom(room);
    if (members.size >= MAX_PER_ROOM) {
      socket.emit('room-full');
      return;
    }
    const existing = [...members.entries()].map(([id, u]) => ({ id, name: u.name }));
    members.set(socket.id, { name, joinedAt: Date.now() });
    socket.data.room = room;
    socket.data.name = name;
    socket.join(room);
    socket.emit('joined', { room, members: existing, maxParticipants: MAX_PER_ROOM });
    socket.to(room).emit('user-joined', { id: socket.id, name });
  });
  socket.on('signal', ({ to, data } = {}) => {
    const room = socket.data.room;
    if (!room || typeof to !== 'string' || !data || typeof data !== 'object') return;
    const target = io.sockets.sockets.get(to);
    if (!target || target.data.room !== room) return;
    target.emit('signal', { from: socket.id, data });
  });
  socket.on('chat-message', ({ text } = {}) => {
    const room = socket.data.room;
    if (!room || typeof text !== 'string') return;
    const message = text.trim().slice(0, 500);
    if (!message) return;
    io.to(room).emit('chat-message', {
      name: socket.data.name || 'کاربر',
      text: message,
      time: Date.now()
    });
  });
  socket.on('leave-room', () => leaveRoom(socket));
  socket.on('disconnect', () => leaveRoom(socket));
});
function leaveRoom(socket) {
  const room = socket.data.room;
  if (!room) return;
  const members = rooms.get(room);
  const user = members && members.get(socket.id);
  if (members) {
    members.delete(socket.id);
    if (members.size === 0) rooms.delete(room);
  }
  socket.to(room).emit('user-left', { id: socket.id, name: user?.name || 'کاربر' });
  socket.leave(room);
  socket.data.room = null;
}
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Who's who listening on http://0.0.0.0:${PORT}`);
});
